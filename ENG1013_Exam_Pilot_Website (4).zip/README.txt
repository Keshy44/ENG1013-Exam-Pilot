ENG1013 EXAM PILOT - FREE ADAPTIVE STUDY WEBSITE

Start locally:
  Double-click index.html to open in Chrome, Edge or another modern browser.
  Keep styles.css and app.js in the same folder.

Publish online for free using Netlify Drop:
  1. Go to https://app.netlify.com/drop
  2. Drag this entire unzipped ENG1013_Adaptive_Study folder (or the ZIP) to the drop area.
  3. Netlify will provide a live HTTPS URL. Save or claim the project to retain control of updates.
  4. Open the link on your study device and use that same URL throughout revision.

Important limitations:
  - Personal progress is stored in the web browser's localStorage on each device.
  - Hosting the site does NOT create a central database or sync devices.
  - To switch devices, use Data & settings > Export backup and Import backup.
  - Clicking a ChatGPT tutor link copies a contextual prompt and opens ChatGPT separately;
    you must paste it to begin a conversation. No API key or paid API usage is needed.
  - The AI tutor DOES NOT automatically see the site's data. You choose what to share.
  - This is not an official Monash exam and the mock questions are generated practice variants.

Content sources:
  ENG1013 2026 Weeks 1–12 workshop decks and lab manuals;
  ENG1013 electrical Weeks 5–8 problem sheets;
  software Python problem sheets and coding standards;
  materials Week 9 problem sheet; and the user-provided final exam assessment information.

Exam: Monday 16 November 2026. Target: 30/40.
